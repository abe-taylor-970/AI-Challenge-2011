import java.util.Comparator;


public class PathLengthComparator implements Comparator<Path> {

		@Override
		public int compare(Path path0, Path path1) {
			  return path0.getDirections().size() - path1.getDirections().size();
		}

}
